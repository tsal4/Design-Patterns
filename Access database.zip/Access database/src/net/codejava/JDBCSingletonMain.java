package net.codejava;

import java.sql.*;
import java.util.Scanner;

class JDBCSingleton {
	private static JDBCSingleton jdbcInstance;
	
	private Connection connection;
	
	private JDBCSingleton() {
		try {
			String dbURL = "jdbc:ucanaccess://Contacts.accdb";
			connection = DriverManager.getConnection(dbURL);
			System.out.println("Successful Connection");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static JDBCSingleton getInstance() {
		if (jdbcInstance == null) {
			jdbcInstance = new JDBCSingleton();
		}
		return jdbcInstance;
	}
	
	public void insertUser(int userId, String userName, String userPassword) {
	    String sql = "INSERT INTO UserData (user_ID, user_name, user_password) VALUES (?, ?, ?)";
	    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	        pstmt.setInt(1, userId);
	        pstmt.setString(2, userName);
	        pstmt.setString(3, userPassword);
	        pstmt.executeUpdate();
	        System.out.println("User inserted successfully!");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public void viewUsers() {
	    String sql = "SELECT * FROM UserData";
	    try (PreparedStatement pstmt = connection.prepareStatement(sql);
	         ResultSet rs = pstmt.executeQuery()) {
	        while (rs.next()) {
	            System.out.println("User ID: " + rs.getInt("user_ID") +
	                               ", Name: " + rs.getString("user_name") +
	                               ", Password: " + rs.getString("user_password"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public void deleteUser(int userId) {
	    String sql = "DELETE FROM UserData WHERE user_ID = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
	        pstmt.setInt(1, userId);
	        int affectedRows = pstmt.executeUpdate();
	        if (affectedRows > 0) {
	            System.out.println("User deleted successfully!");
	        } else {
	            System.out.println("No user found with ID: " + userId);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	

}

public class JDBCSingletonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JDBCSingleton userData = JDBCSingleton.getInstance();
		Scanner in = new Scanner(System.in);
		int choice = 0;
		
		while (choice != 4) {
			System.out.println("\nSelect an operation:");
			System.out.println("1. Insert User");
			System.out.println("2. View Users:");
			System.out.println("3. Delete Users");
			System.out.println("4. Exit");
			System.out.print("Enter your choice:");
			choice = in.nextInt();
			in.nextLine();
			
			switch (choice) {
			case 1:
				System.out.print("Enter User ID: ");
                int userId = in.nextInt();
                in.nextLine();
                System.out.print("Enter User Name: ");
                String userName = in.nextLine();
                System.out.print("Enter User Password: ");
                String userPassword = in.nextLine();
                userData.insertUser(userId, userName, userPassword);
                break;
			case 2:
				userData.viewUsers();
				break;
			case 3:
				System.out.print("Enter the ID of the user to delete: ");
				int userID = in.nextInt();
				userData.deleteUser(userID);
				break;
			case 4:
				in.close();
				break;
			default:
				System.out.println("Error, please enter a valid entry");
			}
		}
		System.out.println("Exiting program");
		
		
	}

}
